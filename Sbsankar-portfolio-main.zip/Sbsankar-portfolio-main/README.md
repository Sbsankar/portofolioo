# OIBSIP---PORTFOLIO--LEVEL-01-TASK-02

LEVEL-01,TASK-02

PORTFOLIO

SKILLS USED :HTML,CSS,BOOTSTRAP

This Appication showcase an individual's work and accomplishments,
typically hosted on a personal website or online platform. The purpose of an online portfolio is to provide a 
visual representation of an individual's skills, expertise, and achievements, and to demonstrate their capabilities
to potential employers, clients, or collaborators
